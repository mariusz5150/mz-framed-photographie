# Wildlife-Daten

`wildlife-data.json` ist die online aktualisierbare Datenquelle der Android-App.

Änderungen an dieser Datei können von bereits installierten Apps geladen werden, ohne eine neue APK zu installieren. Die App hat zusätzlich eine eingebaute Offline-Kopie und funktioniert deshalb auch ohne Internet.
