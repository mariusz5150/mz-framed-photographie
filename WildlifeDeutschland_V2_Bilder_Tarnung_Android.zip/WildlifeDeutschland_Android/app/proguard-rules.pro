# No custom ProGuard rules needed for this simple WebView app.
