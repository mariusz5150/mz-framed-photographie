# Wildlife Deutschland – Android

Version 1.1 mit moderner, Revolut-inspirierter Oberfläche.

## Online aktualisierbare Tierdaten
Die App enthält ihre Daten vollständig offline. Zusätzlich versucht sie, beim Start und über den Sync-Button folgende Datei zu laden:

`https://raw.githubusercontent.com/mariusz5150/mz-framed-photographie/main/data/wildlife-data.json`

Wenn diese Datei später in GitHub geändert wird, übernimmt die installierte App die neuen Tierdaten automatisch und speichert sie lokal. Dafür ist keine neue APK nötig.

## Wann braucht man weiterhin eine neue APK?
Nur bei Änderungen am App-Code/Design, neuen Funktionen oder Android-Systemfunktionen. Reine Tierdaten, Texte, Zeiträume und Arten können über die JSON-Datei aktualisiert werden.

## Build
Das Projekt ist für GitHub Actions vorbereitet. Sobald GitHub-Schreibzugriff für den Connector verfügbar ist, kann es ins Repository übertragen werden.


## Version 1.2
- Tierbilder werden online von Wikipedia/Wikimedia geladen und lokal gecacht.
- Bildquelle/Lizenz wird soweit verfügbar eingeblendet.
- Alle 236 Arten haben „Tarnung & Ansitz“: Standort, Tarnnetz, Handschuhe/Gesicht, Wind/Verhalten.
- Online-Datenupdate erwartet `wildlife-data.json` im Stammverzeichnis des GitHub-Repos.
